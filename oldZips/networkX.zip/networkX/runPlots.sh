#!/bin/bash
python normalPlot.py
python normalPlotNoOP.py
python directedPlot.py
